This is a simple Todo application project done by using HTML,CSS,BOOTSTRAP-GRID and JAVASCRIPT.
Featutes of this Todo-application are :
--> Taking User Input and creating Todos Dynamically.
--> Checking a Todo.
--> Deleting a Todo.
--> Persisting Todos On Reload using Local Storage.
![Screenshot (64)](https://github.com/sviswas/Todo-application/assets/115649646/8b413581-d54a-4206-9b18-3ef5cabfb42d)
